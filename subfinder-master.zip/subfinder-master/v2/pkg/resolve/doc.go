// Package resolve is used to handle resolving records
// It also handles wildcard subdomains and rotating resolvers.
package resolve
